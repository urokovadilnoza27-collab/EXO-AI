
require("dotenv").config();

const express = require("express");
const { GoogleGenAI } = require("@google/genai");

const app = express();
const PORT = 3000;

if (!process.env.GEMINI_API_KEY) {
  console.error("XATO: .env faylida GEMINI_API_KEY topilmadi!");
  process.exit(1);
}

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY
});

app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));

async function generateAIResponse(contents) {
  const maxAttempts = 4;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents
      });

      return response.text || "Javob kelmadi.";
    } catch (error) {
      const status = Number(error.status || error.code);

      const retryable = [429, 500, 502, 503, 504].includes(status);

      if (!retryable || attempt === maxAttempts - 1) {
        throw error;
      }

      const waitTime = 1000 * 2 ** attempt;

      console.log(
        `AI xatosi: ${status || "noma'lum"}. ` +
        `${waitTime / 1000} soniya kutib, qayta uriniladi...`
      );

      await new Promise(resolve =>
        setTimeout(resolve, waitTime)
      );
    }
  }
}

app.post("/api/chat", async (req, res) => {
  try {
    const messages = req.body?.messages;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({
        error: "Xabar topilmadi. Qaytadan yozib ko'r."
      });
    }

    const contents = messages
      .filter(m =>
        m &&
        ["user", "assistant"].includes(m.role) &&
        typeof m.content === "string" &&
        m.content.trim().length > 0
      )
      .map(m => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }]
      }));

    if (contents.length === 0) {
      return res.status(400).json({
        error: "Yuboriladigan matn bo'sh."
      });
    }

    const reply = await generateAIResponse(contents);

    res.json({ reply });
  } catch (error) {
    console.error(
      "AI xatosi:",
      error.status || error.code || "",
      error.message || error
    );

    const status = Number(error.status || error.code);

    if (status === 503 || status === 502 || status === 504) {
      return res.status(503).json({
        error:
          "Google AI hozir band. Biroz kutib, qaytadan urinib ko'r."
      });
    }

    if (status === 429) {
      return res.status(429).json({
        error:
          "AI so'rovlari limiti tugagan bo'lishi mumkin. " +
          "Keyinroq qayta urinib ko'r."
      });
    }

    if (status === 401 || status === 403) {
      return res.status(status).json({
        error:
          "API kaliti yoki Google AI loyihasi ruxsatlarini tekshir."
      });
    }

    res.status(500).json({
      error:
        "AI javob bera olmadi. Terminaldagi xatoni tekshir."
    });
  }
});

app.listen(PORT, () => {
  console.log("================================");
  console.log("       EXO AI ISHGA TUSHDI");
  console.log(`   http://localhost:${PORT}`);
  console.log("================================");
});
